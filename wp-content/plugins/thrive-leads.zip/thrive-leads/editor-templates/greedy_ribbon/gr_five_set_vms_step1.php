<div class="thrv-greedy-ribbon tve_no_drag tve_no_icons tve_element_hover thrv_wrapper tve_gr_five_set tve_red">
	<div class="tve-greedy-ribbon-content tve_editor_main_content">
		<div class="thrv_wrapper thrv_content_container_shortcode">
			<div class="tve_clear"></div>
			<div class="tve_center tve_content_inner" style="width: 480px;min-width:50px; min-height: 2em;">
				<h2 class="tve_p_center rft" style="color: #fff; font-size: 75px;margin-top: 0;margin-bottom: 50px;">
					Start working out
					the <font color="#ed4721">RIGHT</font> way
				</h2>
			</div>
			<div class="tve_clear"></div>
		</div>
		<p class="tve_p_center" style="color: #fff; font-size: 22px;margin-top: 0;margin-bottom: 70px;">
			Nullam bibendum sit amet est et porta. Nam ac felis accumsan leo euismod tincidunt vel vel tortor. Duis nec
			consequat nibh. Morbi pellentesque sollicitudin magna sit amet pretium.
		</p>

		<div class="thrv_wrapper thrv_content_container_shortcode">
			<div class="tve_clear"></div>
			<div class="tve_center tve_content_inner" style="width: 460px;min-width:50px; min-height: 2em;">
				<div class="thrv_wrapper thrv_button_shortcode tve_fullwidthBtn" data-tve-style="1">
					<div class="tve_btn tve_btn3 tve_nb tve_red tve_normalBtn">
						<a class="tve_btnLink tve_evt_manager_listen tve_et_click" href=""
						   data-tcb-events="|open_state_2|">
                                    <span class="tve_left tve_btn_im">
                                        <i></i>
                                        <span class="tve_btn_divider"></span>
                                    </span>
							<span class="tve_btn_txt">READ THE ARTICLES</span>
						</a>
					</div>
				</div>
			</div>
			<div class="tve_clear"></div>
		</div>
	</div>
	<div class="thrv_wrapper thrv_icon aligncenter gr-close-button tve_no_drag">
            <span data-tve-icon="gr-five-set-close"
                  class="tve_sc_icon gr-five-set-close tve_white tve_evt_manager_listen tve_et_click"
                  style="font-size: 90px;" data-tcb-events="|close_form|"></span>
	</div>
</div>


