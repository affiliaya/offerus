<?php

/**
 * Interface TabInterface
 * Any class that implements this interface has to have options to be displayed
 */
interface Thrive_Leads_Tab_Interface {
	public function getOptions();
}
