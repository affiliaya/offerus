<div class="thrv_wrapper thrv_columns tve_clearfix" style="margin-top: 0;margin-bottom: 0;">
	<div class="tve_colm tve_oth">
		<div style="width: 222px; margin-top: 50px;" class="thrv_wrapper tve_image_caption aligncenter">
            <span class="tve_image_frame">
                <a href="">
	                <img class="tve_image" src="<?php echo TVE_LANDING_PAGE_TEMPLATE . '/css/images/whammy_lightbox.png' ?>" style="width: 222px">
                </a>
            </span>
		</div>
	</div>
	<div class="tve_colm tve_tth tve_lst">
		<h5 style="color: #fff; font-size: 25px;line-height: 30px;margin-top: 16px;margin-bottom: 8px;" class="tve_p_center" contenteditable="false">Sign Up Below and We'll Send You Your
			<span class="bold_text">FREE Report</span> Right Away:
		</h5>
		<div class="thrv_wrapper thrv_lead_generation tve_clearfix tve_orange" data-tve-style="1" style="margin-bottom:18px">
			<div class="thrv_lead_generation_code" style="display: none;"></div>
			<div class="thrv_lead_generation_container tve_clearfix">
				<div class="tve_lead_generated_inputs_container tve_clearfix">
					<div class="tve_lead_fields_overlay" style="width: 100%; height: 100%;"></div>
					<div class=" tve_lg_input_container ">
						<input type="text" data-placeholder="Enter your name here" placeholder="Enter your name here" value="" name="first_name">
					</div>
					<div class="tve_lg_input_container">
						<input type="text" data-placeholder="Enter your email here" placeholder="Enter your email here" value="" name="last_name">
					</div>
					<div class="tve_lg_input_container tve_submit_container">
						<button type="Submit">Get the Report Now</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>