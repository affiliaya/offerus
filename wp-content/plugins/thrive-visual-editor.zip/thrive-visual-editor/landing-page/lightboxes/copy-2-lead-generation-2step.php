<div class="thrv_wrapper thrv_columns tve_clearfix" style="margin-top: 50px;margin-bottom: 30px;">
	<div class="tve_colm tve_oth">
		<div style="width: 250px;margin-top: 30px;" class="thrv_wrapper tve_image_caption aligncenter">
            <span class="tve_image_frame">
                <img class="tve_image"
                     src="<?php echo TVE_LANDING_PAGE_TEMPLATE . '/css/images/copy2-product-launch-image.png' ?>"
                     style="width: 250px;"/>
            </span>
		</div>
	</div>
	<div class="tve_colm tve_tth tve_lst">
		<h4 style="color: #1189c6; font-size: 40px; margin-bottom: 20px; margin-top: 0;" class="rft">Sign up below to get access to
			your FREE Product</h4>
		<div class="thrv_wrapper thrv_lead_generation tve_clearfix tve_orange thrv_lead_generation_vertical" data-tve-style="1" style="margin-top: 0;margin-bottom: 0;">
			<div class="thrv_lead_generation_code" style="display: none;"></div>
			<div class="thrv_lead_generation_container tve_clearfix">
				<div class="tve_lead_generated_inputs_container tve_clearfix">
					<div class="tve_lead_fields_overlay" style="width: 100%; height: 100%;"></div>
					<div class=" tve_lg_input_container ">
						<input type="text" data-placeholder="Your Name" placeholder="Your Name" value="" name="first_name"/>
					</div>
					<div class="tve_lg_input_container">
						<input type="text" data-placeholder="Last Name" placeholder="Your E-mail Address" value="" name="email"/>
					</div>
					<div class="tve_lg_input_container tve_submit_container">
						<button type="Submit">SEND ME THE FREE DOWNLOAD</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>