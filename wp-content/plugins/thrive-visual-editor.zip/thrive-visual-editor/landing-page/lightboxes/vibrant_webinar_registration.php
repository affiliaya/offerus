<h5 style="color: #fff; font-size: 30px;margin-top: 16px;margin-bottom: 8px;">
    <span class="bold_text">Enter your email address below and reserve your seat...
        <font color="#1f4640">it's 100% FREE!</font></span>
</h5>
<div class="thrv_wrapper thrv_lead_generation tve_clearfix tve_orange" data-tve-style="1"
     style="margin-bottom:0px">
	<div class="thrv_lead_generation_code" style="display: none;"></div>
	<div class="thrv_lead_generation_container tve_clearfix">
		<div class="tve_lead_generated_inputs_container tve_clearfix">
			<div class="tve_lead_fields_overlay" style="width: 100%; height: 100%;"></div>
			<div class=" tve_lg_input_container ">
				<input type="text" data-placeholder="Enter your name here" placeholder="Enter your name here"
				       value="" name="first_name"/>
			</div>
			<div class="tve_lg_input_container">
				<input type="text" data-placeholder="Enter your email here" placeholder="Enter your email here"
				       value="" name="last_name"/>
			</div>
			<div class="tve_lg_input_container tve_submit_container">
				<button type="Submit">Reserve My Seat &GT;&GT</button>
			</div>
		</div>
	</div>
</div>