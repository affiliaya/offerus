<h1 class="tve_p_center" style="color: #305584; margin: 0; padding: 0; font-size: 30px">Sign Up & We'll Send You Your Free Report</h1>
<h1 class="tve_p_center" style="color: #305584; margin: 0; padding: 0; font-size: 30px">Instantly:</h1>
<div class="thrv_wrapper thrv_lead_generation tve_clearfix tve_centerBtn thrv_lead_generation_vertical tve_orange" data-tve-style="1" style="max-width: 570px; padding: 0; margin-top: 15px; margin-bottom: 15px;">
	<div class="thrv_lead_generation_code" style="display: none;"></div>
	<div class="thrv_lead_generation_container tve_clearfix">
		<div class="tve_lead_generated_inputs_container tve_clearfix">
			<div class="tve_lead_fields_overlay"></div>
			<div class=" tve_lg_input_container ">
				<input type="text" data-placeholder="" value="" name="name"/>
			</div>
			<div class="tve_lg_input_container">
				<input type="text" data-placeholder="" value="" name="email"/>
			</div>
			<div class="tve_lg_input_container tve_submit_container">
				<button type="Submit">Sign Up</button>
			</div>
		</div>
	</div>
</div>
<p class="tve_p_center" style="font-size: 18px; color: #9d9d9d">We respect your privacy. Your email address will never be shared or sold.</p>