<h3 class="tve_p_center rft" style="color: #fff; font-size: 34px;margin-top: 25px;margin-bottom: 00px;">Sign Up Now and
	get a <span class="bold_text">Free</span> Video Lesson</h3>
<div class="thrv_wrapper" style="margin-top: 0;">
	<hr class="tve_sep tve_sep1"/>
</div>

<div style="width: 142px;margin-top: 0;margin-bottom: 20px;" class="thrv_wrapper tve_image_caption aligncenter">
    <span class="tve_image_frame">
        <img class="tve_image"
             src="<?php echo TVE_LANDING_PAGE_TEMPLATE . '/css/images/video-course-lightbox.png' ?>"
             style="width: 142px"/>
    </span>
</div>
<p class="tve_p_center" style="color: #fefefe; font-size: 20px;margin-top: 0;margin-bottom: 20px;">
	Enter your name and email address below to <span class="bold_text underline_text"><a href="">get started</a></span>
	right away!
</p>
<div class="thrv_wrapper thrv_lead_generation tve_clearfix tve_red tve_2 thrv_lead_generation_vertical"
     data-inputs-count="2" data-tve-style="1" style="margin-bottom:0;">
	<div class="thrv_lead_generation_code" style="display: none;"></div>
	<div class="thrv_lead_generation_container tve_clearfix">
		<div class="tve_lead_generated_inputs_container tve_clearfix">
			<div class="tve_lead_fields_overlay"></div>
			<div class=" tve_lg_input_container tve_lg_2 tve_lg_input">
				<input type="text" data-placeholder="Enter Email" placeholder="Enter Email" value="" name="email"/>
			</div>
			<div class="tve_lg_input_container tve_submit_container tve_lg_2 tve_lg_submit">
				<button type="Submit">Subscribe Now &raquo;</button>
			</div>
		</div>
	</div>
</div>
<p class="tve_p_center" style="color: #999999; font-size: 16px;margin-top: 0;margin-bottom: 20px;">Your Privacy is
	protected.</p>