<div><a href="javascript:void(0);" class="click cb-group" data-fn="filter" data-source="group" data-item="<#= group #>"><?php tcb_icon( 'html' ); ?>&nbsp;<#= group #></a></div>
