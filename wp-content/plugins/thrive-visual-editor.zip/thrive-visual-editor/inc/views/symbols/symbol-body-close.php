<?php
/**
 * FileName  symbol-body-close.php.
 * @project: thrive-visual-editor
 * @developer: Dragos Petcu
 * @company: BitStone
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>
</div>
<?php do_action( 'get_footer' ) ?>
<?php wp_footer() ?>
</body>
</html>

