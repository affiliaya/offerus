<div class="control-grid wrap">
	<label for="v-v-url">
		<?php echo __( 'URL', 'thrive-cb' ) ?>
	</label>
	<input type="text" data-setting="url" class="v-url tve_provider_url full-width" id="v-v-url" placeholder="e.g. https://domain.vooplayer.com/22676965">
</div>
<div class="vooplayer-url-validate inline-message"></div>