var base = require( './base' );

module.exports = base.extend( {

	get_route: function () {

		return 'route=traffic';
	}

} );