<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden
}
?>

<span class="click" data-fn="view_conversion_goal_details">
	<?php tcb_icon( 'subs' ) ?><?php echo __( 'Subscription Conversion Goal', 'thrive-ab-page-testing' ); ?>
</span>
