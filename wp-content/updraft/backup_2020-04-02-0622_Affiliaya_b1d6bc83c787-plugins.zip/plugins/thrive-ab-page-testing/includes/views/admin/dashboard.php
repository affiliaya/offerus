<?php
/**
 * Created by PhpStorm.
 * User: Ovidiu
 * Date: 1/16/2018
 * Time: 9:23 AM
 */
?>
<div id="thrive-ab-top-bar" class="thrive-ab-logo-holder" style="margin-left: -20px">
	<div class="thrive-ab-logo">
		<span></span>
	</div>
</div>
<div id="tab-breadcrumbs-wrapper"></div>
<div id="tab-admin-dashboard-wrapper"></div>
