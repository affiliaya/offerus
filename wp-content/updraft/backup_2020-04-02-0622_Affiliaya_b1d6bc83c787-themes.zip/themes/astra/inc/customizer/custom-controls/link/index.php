<?php
/**
 * Index file
 *
 * @package Astra
 * @since Astra 2.3.0
 */

/* Silence is golden, and we agree. */
